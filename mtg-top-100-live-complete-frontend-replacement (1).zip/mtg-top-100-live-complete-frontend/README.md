# MTG Top 100 Live Complete Frontend Package

Replace your repo's `frontend/` folder with the included `frontend/` folder.

Most important file to confirm:

```text
frontend/config.js
```

Make sure `window.MTGMP_API_URL` is your Railway backend URL.
